Andrew Nguyen 20726636
CS 480 Assignment 1

For Exercise 1 run
./q1.sh
plot found in a1q1_perceptron.png

For Exercise 2 run
./q2.sh
plot found in a1q2e.png

For Exercise 3 run
./q3.sh
plots found in a1q3A.png, a1q3B.png, a1q3C.png

For Exercise 4 run
./q4.sh
plots found in a1q4bDPLOT1.png, a1q4bDPLOT2.png, a1q4bEPLOT1.png, a1q4bEPLOT2.png, a1q4c.png

Write up found at a1writeup.pdf
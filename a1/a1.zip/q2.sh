#! /bin/bash 

python3 a1q2.py
#! /bin/bash 

python3 a1q1.py
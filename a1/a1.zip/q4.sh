#! /bin/bash 

python3 a1q4.py
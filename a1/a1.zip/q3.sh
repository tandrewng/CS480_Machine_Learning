#! /bin/bash 

python3 a1q3.py